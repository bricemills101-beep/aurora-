package dev.aurora.mixin;

import dev.aurora.module.Freecam;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityMixin {
    /** Mouse movement turns the camera instead of the real player (so no rotation is ever sent to the server). */
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void aurora$look(double dx, double dy, CallbackInfo ci) {
        if (Freecam.active() && (Object) this == MinecraftClient.getInstance().player) {
            Freecam.look(dx, dy);
            ci.cancel();
        }
    }
}
