package dev.aurora.mixin;

import dev.aurora.module.Freecam;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setRotation(float yaw, float pitch);
    @Shadow protected abstract void setPos(double x, double y, double z);

    @Inject(method = "update", at = @At("TAIL"))
    private void aurora$freecam(CallbackInfo ci) {
        if (!Freecam.active()) return;
        Freecam.frame(MinecraftClient.getInstance());
        setRotation(Freecam.yaw, Freecam.pitch);
        setPos(Freecam.x, Freecam.y, Freecam.z);
    }

    /** Makes the game treat the view as third person so the real player model is drawn and the hand is hidden. */
    @Inject(method = "isThirdPerson", at = @At("HEAD"), cancellable = true)
    private void aurora$thirdPerson(CallbackInfoReturnable<Boolean> cir) {
        if (Freecam.active() && Freecam.INSTANCE.showPlayer.get()) cir.setReturnValue(true);
    }
}
