package dev.aurora.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.Locale;

public final class NumberSetting extends Setting {
    private double value;
    public final double min, max, step;
    private final String suffix;

    public NumberSetting(String name, double def, double min, double max, double step, String suffix) {
        super(name);
        this.min = min; this.max = max; this.step = step; this.suffix = suffix;
        set(def);
    }

    public double get() { return value; }
    public int intValue() { return (int) Math.round(value); }
    public float floatValue() { return (float) value; }

    public void set(double v) {
        v = Math.round((v - min) / step) * step + min;
        value = Math.max(min, Math.min(max, v));
    }

    public double fraction() { return (value - min) / (max - min); }
    public void setFraction(double f) { set(min + Math.max(0, Math.min(1, f)) * (max - min)); }

    public String display() {
        if (step >= 1) return Math.round(value) + suffix;
        return String.format(Locale.ROOT, "%.1f", value) + suffix;
    }

    @Override public JsonElement toJson() { return new JsonPrimitive(value); }
    @Override public void fromJson(JsonElement e) { if (e.isJsonPrimitive()) set(e.getAsDouble()); }
}
