package dev.aurora.setting;

import com.google.gson.JsonElement;
import java.util.function.BooleanSupplier;

public abstract class Setting {
    public final String name;
    private BooleanSupplier visible = () -> true;

    protected Setting(String name) { this.name = name; }

    public void setVisible(BooleanSupplier v) { this.visible = v; }
    public boolean isVisible() { return visible.getAsBoolean(); }

    public abstract JsonElement toJson();
    public abstract void fromJson(JsonElement e);
}
