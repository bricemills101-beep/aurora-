package dev.aurora.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import dev.aurora.util.ColorUtil;

public final class ColorSetting extends Setting {
    private float h, s, b;

    public ColorSetting(String name, int rgb) { super(name); setRgb(rgb); }

    public int rgb() { return ColorUtil.hsb(h, s, b); }
    public void setRgb(int rgb) { float[] v = ColorUtil.toHsb(rgb); h = v[0]; s = v[1]; b = v[2]; }

    public float hue() { return h; }
    public float sat() { return s; }
    public float bri() { return b; }
    public void setHue(double v) { h = (float) Math.max(0, Math.min(0.999, v)); }
    public void setSat(double v) { s = (float) Math.max(0, Math.min(1, v)); }
    public void setBri(double v) { b = (float) Math.max(0, Math.min(1, v)); }

    @Override public JsonElement toJson() { return new JsonPrimitive(rgb()); }
    @Override public void fromJson(JsonElement e) { if (e.isJsonPrimitive()) setRgb(e.getAsInt()); }
}
