package dev.aurora.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class ModeSetting extends Setting {
    public final String[] modes;
    private int index;

    /** First mode is the default. */
    public ModeSetting(String name, String... modes) { super(name); this.modes = modes; }

    public ModeSetting def(String mode) {
        for (int i = 0; i < modes.length; i++) if (modes[i].equals(mode)) index = i;
        return this;
    }

    public String get() { return modes[index]; }
    public int index() { return index; }
    public boolean is(String m) { return modes[index].equals(m); }
    public void next() { index = (index + 1) % modes.length; }
    public void prev() { index = (index + modes.length - 1) % modes.length; }

    @Override public JsonElement toJson() { return new JsonPrimitive(get()); }
    @Override public void fromJson(JsonElement e) {
        if (!e.isJsonPrimitive()) return;
        String s = e.getAsString();
        for (int i = 0; i < modes.length; i++) if (modes[i].equals(s)) index = i;
    }
}
