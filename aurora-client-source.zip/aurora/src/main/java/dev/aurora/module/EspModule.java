package dev.aurora.module;

import dev.aurora.render.View;
import dev.aurora.setting.BoolSetting;
import dev.aurora.setting.ColorSetting;
import dev.aurora.setting.ModeSetting;
import dev.aurora.setting.NumberSetting;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.World;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Shared logic for modules that highlight block entities. */
public abstract class EspModule extends Module {
    public record Entry(Box box, ColorSetting color, String label) {}

    public final ModeSetting mode = new ModeSetting("Mode", "Outline", "Filled", "Outline + Fill", "Corners", "Flat Box");
    public final NumberSetting outlineOpacity = new NumberSetting("Outline Opacity", 90, 5, 100, 1, "%");
    public final NumberSetting fillOpacity = new NumberSetting("Fill Opacity", 25, 1, 100, 1, "%");
    public final NumberSetting lineWidth = new NumberSetting("Line Width", 1, 1, 4, 1, "px");
    public final ModeSetting colorMode = new ModeSetting("Color Mode", "Per Type", "Rainbow", "Distance");
    public final NumberSetting rainbowSpeed = new NumberSetting("Rainbow Speed", 5, 1, 30, 1, "");
    public final BoolSetting distanceFade = new BoolSetting("Distance Fade", true);
    public final NumberSetting range = new NumberSetting("Range", 128, 16, 512, 8, "m");
    public final NumberSetting maxTargets = new NumberSetting("Max Targets", 150, 10, 500, 10, "");
    public final NumberSetting scanInterval = new NumberSetting("Scan Interval", 10, 2, 40, 1, "t");
    public final BoolSetting tracers = new BoolSetting("Tracers", false);
    public final NumberSetting tracerOpacity = new NumberSetting("Tracer Opacity", 60, 5, 100, 1, "%");
    public final ModeSetting tracerOrigin = new ModeSetting("Tracer Origin", "Crosshair", "Bottom");
    public final BoolSetting labels = new BoolSetting("Labels", false);
    public final BoolSetting showDistance = new BoolSetting("Show Distance", true);

    private volatile List<Entry> entries = List.of();
    private int timer;

    protected EspModule(String name, String description) {
        super(name, description, ModuleCategory.RENDER);
    }

    /** Call from the subclass constructor, after adding type-specific settings. */
    protected void addCommon() {
        add(mode);
        add(outlineOpacity, () -> !mode.is("Filled"));
        add(fillOpacity, () -> mode.is("Filled") || mode.is("Outline + Fill"));
        add(lineWidth, () -> !mode.is("Filled"));
        add(colorMode);
        add(rainbowSpeed, () -> colorMode.is("Rainbow"));
        add(distanceFade);
        add(range);
        add(maxTargets);
        add(scanInterval);
        add(tracers);
        add(tracerOpacity, tracers::get);
        add(tracerOrigin, tracers::get);
        add(labels);
        add(showDistance, labels::get);
    }

    public List<Entry> entries() { return entries; }

    /** Return null to ignore this block entity. */
    protected abstract Entry classify(World world, BlockPos pos, BlockEntity be);

    @Override protected void onEnable() { timer = 0; }
    @Override protected void onDisable() { entries = List.of(); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) { entries = List.of(); return; }
        if (--timer > 0) return;
        timer = scanInterval.intValue();
        scan(mc);
    }

    private record Scored(Entry e, double d) {}

    private void scan(MinecraftClient mc) {
        ClientWorld w = mc.world;
        Vec3d c = View.cameraPos(mc, 1f);
        double r = range.get(), r2 = r * r;
        int cr = (int) Math.ceil(r / 16.0) + 1;
        int ccx = ((int) Math.floor(c.x)) >> 4, ccz = ((int) Math.floor(c.z)) >> 4;

        List<Scored> found = new ArrayList<>();
        for (int dx = -cr; dx <= cr; dx++) {
            for (int dz = -cr; dz <= cr; dz++) {
                WorldChunk ch = w.getChunkManager().getWorldChunk(ccx + dx, ccz + dz);
                if (ch == null) continue;
                for (BlockEntity be : ch.getBlockEntities().values()) {
                    BlockPos p = be.getPos();
                    double ex = p.getX() + 0.5 - c.x, ey = p.getY() + 0.5 - c.y, ez = p.getZ() + 0.5 - c.z;
                    double d2 = ex * ex + ey * ey + ez * ez;
                    if (d2 > r2) continue;
                    Entry e = classify(w, p, be);
                    if (e != null) found.add(new Scored(e, d2));
                }
            }
        }
        found.sort(Comparator.comparingDouble(Scored::d));
        int max = maxTargets.intValue();
        List<Entry> out = new ArrayList<>(Math.min(max, found.size()));
        for (int i = 0; i < found.size() && i < max; i++) out.add(found.get(i).e());
        entries = out;
    }

    // ---- helpers for subclasses ----
    protected final Entry entry(World w, BlockPos pos, ColorSetting c, String label) {
        BlockState st = w.getBlockState(pos);
        VoxelShape sh = st.getOutlineShape(w, pos);
        Box box = sh.isEmpty() ? new Box(pos) : sh.getBoundingBox().offset(pos);
        return new Entry(box, c, label);
    }

    /** Like entry(), but merges the two halves of a double chest into one box. */
    protected final Entry chestEntry(World w, BlockPos pos, ColorSetting c, String label) {
        BlockState st = w.getBlockState(pos);
        if (st.contains(ChestBlock.CHEST_TYPE) && st.get(ChestBlock.CHEST_TYPE) != ChestType.SINGLE) {
            Direction facing = st.get(ChestBlock.FACING);
            Direction toOther = st.get(ChestBlock.CHEST_TYPE) == ChestType.LEFT
                    ? facing.rotateYClockwise() : facing.rotateYCounterclockwise();
            BlockPos other = pos.offset(toOther);
            if (w.getBlockEntity(other) instanceof ChestBlockEntity) {
                if (pos.asLong() > other.asLong()) return null; // the other half emits the merged box
                Entry a = entry(w, pos, c, label), b = entry(w, other, c, label);
                return new Entry(a.box().union(b.box()), c, label);
            }
        }
        return entry(w, pos, c, label);
    }
}
