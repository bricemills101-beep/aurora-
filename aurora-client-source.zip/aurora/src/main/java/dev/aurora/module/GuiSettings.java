package dev.aurora.module;

import dev.aurora.setting.BoolSetting;
import dev.aurora.setting.ColorSetting;
import dev.aurora.setting.NumberSetting;
import dev.aurora.util.ColorUtil;

public final class GuiSettings extends Module {
    public final ColorSetting accent = add(new ColorSetting("Accent", 0x3FB6FF), () -> !this.rainbow.get());
    public final BoolSetting rainbow = add(new BoolSetting("Rainbow Accent", false));
    public final NumberSetting dim = add(new NumberSetting("Background Dim", 55, 0, 90, 1, "%"));
    public final BoolSetting tooltips = add(new BoolSetting("Tooltips", true));

    public GuiSettings() {
        super("ClickGUI", "Appearance of this menu. Open/close with Right Shift (rebind in Controls).", ModuleCategory.CLIENT);
    }

    @Override public boolean toggleable() { return false; }

    public int accentRgb() {
        if (rainbow.get()) return ColorUtil.hsb((System.currentTimeMillis() % 8000L) / 8000f, 0.65f, 1f);
        return accent.rgb();
    }

    public int accent2Rgb() {
        float[] hsb = ColorUtil.toHsb(accentRgb());
        return ColorUtil.hsb(hsb[0] + 0.12f, hsb[1], hsb[2]);
    }
}
