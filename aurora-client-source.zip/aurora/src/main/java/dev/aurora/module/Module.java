package dev.aurora.module;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.aurora.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;

public abstract class Module {
    public static final KeyBinding.Category KEY_CATEGORY =
            KeyBinding.Category.create(Identifier.of("aurora", "main"));

    public final String name;
    public final String description;
    public final ModuleCategory category;
    public final KeyBinding key;
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    private boolean enabled;
    private final List<Setting> settings = new ArrayList<>();

    protected Module(String name, String description, ModuleCategory category) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.key = new KeyBinding("key.aurora." + name.toLowerCase(Locale.ROOT).replace(" ", ""),
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, KEY_CATEGORY);
    }

    // ---- behaviour hooks ----
    public boolean toggleable() { return true; }
    public boolean persistEnabled() { return true; }
    protected boolean canEnable() { return true; }
    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick(MinecraftClient mc) {}

    // ---- state ----
    public boolean isEnabled() { return enabled; }
    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean e) {
        if (e == enabled) return;
        if (e && !canEnable()) return;
        enabled = e;
        if (e) onEnable(); else onDisable();
    }

    // ---- settings ----
    protected <S extends Setting> S add(S s) { settings.add(s); return s; }
    protected <S extends Setting> S add(S s, BooleanSupplier visible) { s.setVisible(visible); return add(s); }
    public List<Setting> settings() { return Collections.unmodifiableList(settings); }

    // ---- persistence ----
    public JsonObject save() {
        JsonObject o = new JsonObject();
        if (persistEnabled() && toggleable()) o.addProperty("enabled", enabled);
        JsonObject s = new JsonObject();
        for (Setting st : settings) s.add(st.name, st.toJson());
        o.add("settings", s);
        return o;
    }

    public void load(JsonObject o) {
        if (persistEnabled() && toggleable() && o.has("enabled")) setEnabled(o.get("enabled").getAsBoolean());
        if (o.has("settings") && o.get("settings").isJsonObject()) {
            JsonObject s = o.getAsJsonObject("settings");
            for (Setting st : settings) {
                JsonElement e = s.get(st.name);
                if (e != null) {
                    try { st.fromJson(e); } catch (Exception ignored) {}
                }
            }
        }
    }
}
