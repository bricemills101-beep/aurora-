package dev.aurora.module;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.aurora.gui.ClickGuiScreen;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();
    public static KeyBinding OPEN_GUI;

    public static StorageFinder STORAGE;
    public static SpawnerFinder SPAWNER;
    public static Freecam FREECAM;
    public static GuiSettings GUI;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("aurora.json"); }

    private ModuleManager() {}

    public static void init() {
        OPEN_GUI = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.aurora.gui",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, Module.KEY_CATEGORY));

        STORAGE = reg(new StorageFinder());
        SPAWNER = reg(new SpawnerFinder());
        FREECAM = reg(new Freecam());
        GUI = reg(new GuiSettings());
        load();
    }

    private static <M extends Module> M reg(M m) {
        MODULES.add(m);
        if (m.toggleable()) KeyBindingHelper.registerKeyBinding(m.key);
        return m;
    }

    public static List<Module> of(ModuleCategory c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.category == c) out.add(m);
        return out;
    }

    public static void tick(MinecraftClient mc) {
        for (Module m : MODULES) {
            if (m.toggleable()) while (m.key.wasPressed()) m.toggle();
        }
        while (OPEN_GUI.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new ClickGuiScreen());
        }
        for (Module m : MODULES) if (m.isEnabled()) m.onTick(mc);
    }

    /** Called when leaving a world/server: modules that must not persist are switched off. */
    public static void onDisconnect() {
        for (Module m : MODULES) if (!m.persistEnabled() && m.isEnabled()) m.setEnabled(false);
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : MODULES) root.add(m.name, m.save());
            Files.writeString(file(), GSON.toJson(root));
        } catch (Exception e) {
            System.err.println("[Aurora] Failed to save config: " + e);
        }
    }

    private static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            JsonObject root = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            for (Module m : MODULES) {
                if (root.has(m.name)) m.load(root.getAsJsonObject(m.name));
            }
        } catch (Exception e) {
            System.err.println("[Aurora] Failed to load config: " + e);
        }
    }
}
