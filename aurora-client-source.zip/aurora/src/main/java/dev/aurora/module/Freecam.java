package dev.aurora.module;

import dev.aurora.setting.BoolSetting;
import dev.aurora.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.input.Input;
import net.minecraft.client.option.GameOptions;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Client-side only free camera.
 *
 * The real player is frozen by swapping its Input for an empty one (so no movement, jump,
 * sneak or sprint is ever applied or sent to the server) and mouse-look is redirected to the camera.
 * The camera position/rotation are applied in CameraMixin.
 */
public final class Freecam extends Module {
    public static Freecam INSTANCE;

    // camera state
    public static double x, y, z;
    public static float yaw, pitch;
    private static double vx, vy, vz;
    private static long lastNanos;

    // input swap
    private static final Input DUMMY = new Input();
    private static Input realInput;

    public final NumberSetting speed = add(new NumberSetting("Speed", 12, 2, 80, 1, " b/s"));
    public final NumberSetting sprintMult = add(new NumberSetting("Sprint Multiplier", 2.5, 1, 6, 0.5, "x"));
    public final NumberSetting smoothing = add(new NumberSetting("Smoothing", 35, 0, 100, 1, "%"));
    public final BoolSetting showPlayer = add(new BoolSetting("Show Player", true));
    public final BoolSetting interact = add(new BoolSetting("Allow Interaction", false));

    public Freecam() {
        super("Freecam", "Fly around with a detached camera. Your real position never changes.", ModuleCategory.CAMERA);
        INSTANCE = this;
    }

    public static boolean active() { return INSTANCE != null && INSTANCE.isEnabled(); }

    @Override public boolean persistEnabled() { return false; }
    @Override protected boolean canEnable() { return mc.player != null && mc.world != null; }

    @Override
    protected void onEnable() {
        ClientPlayerEntity p = mc.player;
        Vec3d eye = p.getEyePos();
        x = eye.x; y = eye.y; z = eye.z;
        yaw = p.getYaw();
        pitch = p.getPitch();
        vx = vy = vz = 0;
        lastNanos = 0;
        grabInput(p);
    }

    @Override
    protected void onDisable() { releaseInput(mc.player); }

    private static void grabInput(ClientPlayerEntity p) {
        if (p.input != DUMMY) {
            realInput = p.input;
            p.input = DUMMY;
        }
    }

    private static void releaseInput(ClientPlayerEntity p) {
        if (p != null && p.input == DUMMY && realInput != null) p.input = realInput;
        realInput = null;
    }

    /** START_CLIENT_TICK: runs before vanilla handles key presses. */
    public static void preTick(MinecraftClient mc) {
        if (!active()) return;
        ClientPlayerEntity p = mc.player;
        if (p == null) { INSTANCE.setEnabled(false); return; }
        grabInput(p); // also re-applies after respawn

        if (!INSTANCE.interact.get()) {
            GameOptions o = mc.options;
            while (o.attackKey.wasPressed()) { }
            while (o.useKey.wasPressed()) { }
            while (o.pickItemKey.wasPressed()) { }
            o.attackKey.setPressed(false);
            o.useKey.setPressed(false);
        }
    }

    /** Mouse delta redirected from Entity#changeLookDirection (see EntityMixin). */
    public static void look(double dx, double dy) {
        yaw += (float) (dx * 0.15);
        pitch = MathHelper.clamp(pitch + (float) (dy * 0.15), -90f, 90f);
    }

    /** Called once per rendered frame from CameraMixin. */
    public static void frame(MinecraftClient mc) {
        long now = System.nanoTime();
        if (lastNanos == 0) lastNanos = now;
        double dt = Math.min(0.1, (now - lastNanos) / 1e9);
        lastNanos = now;
        if (dt <= 0) return;

        GameOptions o = mc.options;
        double fwd = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        double side = (o.rightKey.isPressed() ? 1 : 0) - (o.leftKey.isPressed() ? 1 : 0);
        double vert = (o.jumpKey.isPressed() ? 1 : 0) - (o.sneakKey.isPressed() ? 1 : 0);

        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        double fx = -Math.sin(yr) * Math.cos(pr), fy = -Math.sin(pr), fz = Math.cos(yr) * Math.cos(pr);
        double rx = -Math.cos(yr), rz = -Math.sin(yr);

        double wx = fx * fwd + rx * side;
        double wy = fy * fwd + vert;
        double wz = fz * fwd + rz * side;
        double len = Math.sqrt(wx * wx + wy * wy + wz * wz);
        if (len > 1e-6) { wx /= len; wy /= len; wz /= len; }

        double sp = INSTANCE.speed.get() * (o.sprintKey.isPressed() ? INSTANCE.sprintMult.get() : 1.0);
        double sm = INSTANCE.smoothing.get();
        double k = sm <= 0 ? 1.0 : 1.0 - Math.exp(-dt * (40.0 - 0.35 * sm));
        vx += (wx * sp - vx) * k;
        vy += (wy * sp - vy) * k;
        vz += (wz * sp - vz) * k;

        x += vx * dt;
        y += vy * dt;
        z += vz * dt;
    }
}
