package dev.aurora.module;

import dev.aurora.setting.BoolSetting;
import dev.aurora.setting.ColorSetting;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.TrialSpawnerBlockEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.Set;

public final class SpawnerFinder extends EspModule {
    private final ColorSetting spawnerC = new ColorSetting("Spawner Color", 0xFF3B3B);
    private final BoolSetting trial     = new BoolSetting("Trial Spawners", true);
    private final ColorSetting trialC   = new ColorSetting("Trial Color", 0x2EE6C5);
    private final BoolSetting notify    = new BoolSetting("Notify On Find", true);

    private final Set<Long> known = new HashSet<>();

    public SpawnerFinder() {
        super("SpawnerFinder", "Highlights monster spawners (and optionally trial spawners).");
        add(spawnerC, () -> colorMode.is("Per Type"));
        add(trial);
        add(trialC, () -> trial.get() && colorMode.is("Per Type"));
        add(notify);
        addCommon();
    }

    @Override protected void onEnable() { super.onEnable(); known.clear(); }
    @Override protected void onDisable() { super.onDisable(); known.clear(); }

    @Override
    protected Entry classify(World w, BlockPos pos, BlockEntity be) {
        if (be instanceof MobSpawnerBlockEntity) {
            announce(pos, "Spawner");
            return entry(w, pos, spawnerC, "Spawner");
        }
        if (trial.get() && be instanceof TrialSpawnerBlockEntity) {
            announce(pos, "Trial Spawner");
            return entry(w, pos, trialC, "Trial Spawner");
        }
        return null;
    }

    private void announce(BlockPos pos, String what) {
        if (!notify.get() || mc.player == null) return;
        if (known.add(pos.asLong())) {
            mc.player.sendMessage(Text.literal("[Aurora] " + what + " at "
                    + pos.getX() + " " + pos.getY() + " " + pos.getZ()), false);
        }
    }
}
