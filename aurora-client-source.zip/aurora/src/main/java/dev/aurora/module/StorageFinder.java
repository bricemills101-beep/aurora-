package dev.aurora.module;

import dev.aurora.setting.BoolSetting;
import dev.aurora.setting.ColorSetting;
import net.minecraft.block.entity.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public final class StorageFinder extends EspModule {
    private final BoolSetting chests   = new BoolSetting("Chests", true);
    private final ColorSetting chestC  = new ColorSetting("Chest Color", 0xFFAA00);
    private final BoolSetting trapped  = new BoolSetting("Trapped Chests", true);
    private final ColorSetting trapC   = new ColorSetting("Trapped Color", 0xFF4D4D);
    private final BoolSetting shulkers = new BoolSetting("Shulker Boxes", true);
    private final ColorSetting shulkC  = new ColorSetting("Shulker Color", 0xD056FF);
    private final BoolSetting droppers = new BoolSetting("Droppers", true);
    private final ColorSetting dropC   = new ColorSetting("Dropper Color", 0x55FF7A);
    private final BoolSetting barrels  = new BoolSetting("Barrels", false);
    private final ColorSetting barrelC = new ColorSetting("Barrel Color", 0xC98A4B);
    private final BoolSetting enders   = new BoolSetting("Ender Chests", false);
    private final ColorSetting enderC  = new ColorSetting("Ender Color", 0x3D5CFF);
    private final BoolSetting dispens  = new BoolSetting("Dispensers", false);
    private final ColorSetting dispC   = new ColorSetting("Dispenser Color", 0x9AA3B2);
    private final BoolSetting hoppers  = new BoolSetting("Hoppers", false);
    private final ColorSetting hopC    = new ColorSetting("Hopper Color", 0x6E7787);

    public StorageFinder() {
        super("StorageFinder", "Highlights chests, shulker boxes, droppers and other containers.");
        typeRow(chests, chestC);
        typeRow(trapped, trapC);
        typeRow(shulkers, shulkC);
        typeRow(droppers, dropC);
        typeRow(barrels, barrelC);
        typeRow(enders, enderC);
        typeRow(dispens, dispC);
        typeRow(hoppers, hopC);
        addCommon();
    }

    private void typeRow(BoolSetting toggle, ColorSetting color) {
        add(toggle);
        add(color, () -> toggle.get() && colorMode.is("Per Type"));
    }

    @Override
    protected Entry classify(World w, BlockPos pos, BlockEntity be) {
        // order matters: subclasses first
        if (be instanceof TrappedChestBlockEntity) return trapped.get() ? chestEntry(w, pos, trapC, "Trapped Chest") : null;
        if (be instanceof ChestBlockEntity)        return chests.get()  ? chestEntry(w, pos, chestC, "Chest") : null;
        if (be instanceof EnderChestBlockEntity)   return enders.get()  ? entry(w, pos, enderC, "Ender Chest") : null;
        if (be instanceof ShulkerBoxBlockEntity)   return shulkers.get() ? entry(w, pos, shulkC, "Shulker Box") : null;
        if (be instanceof BarrelBlockEntity)       return barrels.get() ? entry(w, pos, barrelC, "Barrel") : null;
        if (be instanceof DropperBlockEntity)      return droppers.get() ? entry(w, pos, dropC, "Dropper") : null;
        if (be instanceof DispenserBlockEntity)    return dispens.get() ? entry(w, pos, dispC, "Dispenser") : null;
        if (be instanceof HopperBlockEntity)       return hoppers.get() ? entry(w, pos, hopC, "Hopper") : null;
        return null;
    }
}
