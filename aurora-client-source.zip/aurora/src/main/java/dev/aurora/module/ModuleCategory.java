package dev.aurora.module;

public enum ModuleCategory {
    RENDER("Render"), CAMERA("Camera"), CLIENT("Client");

    public final String label;
    ModuleCategory(String label) { this.label = label; }
}
