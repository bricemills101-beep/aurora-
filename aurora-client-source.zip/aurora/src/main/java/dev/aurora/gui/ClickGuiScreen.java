package dev.aurora.gui;

import dev.aurora.module.GuiSettings;
import dev.aurora.module.Module;
import dev.aurora.module.ModuleCategory;
import dev.aurora.module.ModuleManager;
import dev.aurora.setting.*;
import dev.aurora.util.ColorUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.function.DoubleToIntFunction;

/**
 * Immediate-mode ClickGUI: every frame the layout is rebuilt and each interactive rectangle
 * registers a "hit" that the mouse handlers use afterwards.
 *
 * Left click a module = toggle, right click = expand its settings.
 * Drag panel headers to move them, right click a header to collapse, scroll to scroll long panels.
 */
public class ClickGuiScreen extends Screen {
    private static final int PW = 160, HEAD = 20, ROW = 18, COLOR_PICKER_H = 40;

    // ---- persistent between openings ----
    private static final List<PanelState> PANELS = new ArrayList<>();
    private static final Set<Module> OPEN = new HashSet<>();
    private static final Set<Setting> COLOR_OPEN = new HashSet<>();
    private static final Map<Object, Float> ANIMS = new HashMap<>();

    private static final class PanelState {
        final ModuleCategory cat;
        int x, y;
        boolean collapsed;
        double scroll;
        int contentH, visibleH;
        PanelState(ModuleCategory cat, int x, int y) { this.cat = cat; this.x = x; this.y = y; }
    }

    private record K(Object o, String t) {}
    private interface Act { void run(int button, double mx, double my); }
    private interface Drag { void to(double mx, double my); }
    private record Hit(int x1, int y1, int x2, int y2, int clipTop, int clipBottom, Act act) {}

    private final List<Hit> hits = new ArrayList<>();
    private Drag drag;
    private long lastNanos = System.nanoTime();
    private float dt;
    private int clipTop, clipBottom;
    private int accent, accent2;
    private String tooltip;

    public ClickGuiScreen() {
        super(Text.literal("Aurora"));
        if (PANELS.isEmpty()) {
            int i = 0;
            for (ModuleCategory c : ModuleCategory.values()) PANELS.add(new PanelState(c, 24 + i++ * (PW + 14), 24));
        }
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void removed() { ModuleManager.save(); }

    // ============================================================ rendering

    @Override
    public void render(DrawContext g, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        dt = Math.min(0.1f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        hits.clear();
        tooltip = null;

        GuiSettings gs = ModuleManager.GUI;
        int acc = gs.accentRgb();
        accent = acc;
        accent2 = gs.accent2Rgb();

        float dim = (float) gs.dim.get() / 100f;
        g.fillGradient(0, 0, width, height, ColorUtil.argb(0x04060C, dim), ColorUtil.argb(ColorUtil.lerp(0x04060C, acc, 0.18f), dim * 0.85f));

        for (PanelState p : new ArrayList<>(PANELS)) renderPanel(g, p, mouseX, mouseY);

        TextRenderer tr = textRenderer;
        g.drawText(tr, "Aurora Client", 8, height - 22, ColorUtil.argb(0xFFFFFF, 0.85f), true);
        g.drawText(tr, "LMB toggle  |  RMB expand  |  Drag headers  |  RShift / Esc close", 8, height - 11,
                ColorUtil.argb(0xFFFFFF, 0.4f), false);

        if (tooltip != null && gs.tooltips.get()) {
            int tw = tr.getWidth(tooltip);
            int tx = Math.min(width - tw - 12, Math.max(4, mouseX + 10)), ty = Math.min(height - 24, mouseY + 12);
            rrect(g, tx - 4, ty - 3, tw + 8, 14, 0xF0080A10, true, true);
            g.drawText(tr, tooltip, tx, ty, 0xFFE6EAF2, false);
        }
    }

    private void renderPanel(DrawContext g, PanelState p, int mx, int my) {
        TextRenderer tr = textRenderer;
        List<Module> mods = ModuleManager.of(p.cat);
        int x = p.x, y = p.y;

        int content = 0;
        for (Module m : mods) content += ROW + Math.round(settingsHeight(m) * openAmount(m));
        int maxBody = Math.max(60, height - y - HEAD - 36);
        int body = p.collapsed ? 0 : Math.min(content, maxBody);
        p.contentH = content;
        p.visibleH = body;
        p.scroll = Math.max(0, Math.min(p.scroll, Math.max(0, content - body)));

        // shadow + body + header
        rrect(g, x - 1, y - 1, PW + 2, HEAD + body + 2, 0x38000000, true, true);
        rrect(g, x, y, PW, HEAD + body, 0xEE0C0F16, true, true);
        rrect(g, x, y, PW, HEAD, 0xFF131823, true, body == 0);
        gradient(g, x + 6, y + HEAD - 1, PW - 12, 1, t -> ColorUtil.lerp(accent, accent2, (float) t) | 0xFF000000);

        String title = p.cat.label.toUpperCase(Locale.ROOT);
        g.drawText(tr, title, x + 9, y + 6, 0xFF000000 | accent, true);
        String chev = p.collapsed ? "+" : "-";
        g.drawText(tr, chev, x + PW - 12, y + 6, 0xFF8F97A8, false);

        addHit(x, y, x + PW, y + HEAD, (b, ax, ay) -> {
            if (b == 0) {
                PANELS.remove(p); PANELS.add(p); // bring to front
                double ox = ax - p.x, oy = ay - p.y;
                drag = (nx, ny) -> { p.x = (int) (nx - ox); p.y = (int) (ny - oy); };
            } else if (b == 1) {
                p.collapsed = !p.collapsed;
            }
        });

        if (body <= 0) return;

        int top = y + HEAD, bottom = top + body;
        g.enableScissor(x, top, x + PW, bottom);
        int oldTop = clipTop, oldBot = clipBottom;
        clipTop = top; clipBottom = bottom;

        int cy = top - (int) p.scroll;
        for (Module m : mods) cy = renderModule(g, m, x, cy, mx, my, top, bottom);

        g.disableScissor();
        clipTop = oldTop; clipBottom = oldBot;

        if (content > body) { // scrollbar
            int bh = Math.max(12, body * body / content);
            int by = top + (int) ((body - bh) * (p.scroll / (content - body)));
            g.fill(x + PW - 3, by, x + PW - 1, by + bh, ColorUtil.argb(accent, 0.7f));
        }
    }

    private int renderModule(DrawContext g, Module m, int x, int y, int mx, int my, int pTop, int pBottom) {
        TextRenderer tr = textRenderer;
        boolean hover = mx >= x && mx < x + PW && my >= Math.max(y, pTop) && my < Math.min(y + ROW, pBottom);
        float hv = anim(new K(m, "h"), hover ? 1f : 0f, 14f);
        float en = anim(new K(m, "e"), m.isEnabled() ? 1f : 0f, 12f);
        boolean tg = m.toggleable();

        if (hv > 0.01f) g.fill(x, y, x + PW, y + ROW, ColorUtil.argb(0xFFFFFF, 0.06f * hv));
        if (tg && en > 0.01f) g.fill(x, y + 3, x + 2, y + ROW - 3, ColorUtil.argb(accent, en));

        int textRgb = tg ? ColorUtil.lerp(0xB4BAC6, accent, en) : 0xD5DAE5;
        g.drawText(tr, m.name, x + 9, y + 5, 0xFF000000 | textRgb, false);

        boolean hasSettings = !m.settings().isEmpty();
        int rightX = x + PW - 8;
        if (tg) {
            pill(g, rightX - 18, y + 5, 18, 8, en);
            rightX -= 26;
        }
        if (hasSettings) {
            String arrow = OPEN.contains(m) ? "v" : ">";
            g.drawText(tr, arrow, rightX - tr.getWidth(arrow), y + 5, 0xFF6C7587, false);
        }

        if (hover && tooltip == null) tooltip = m.description;
        addHit(x, y, x + PW, y + ROW, (b, ax, ay) -> {
            if (b == 0 && tg) m.toggle();
            else if (b == 1 || (b == 0 && !tg)) { if (!OPEN.remove(m)) OPEN.add(m); }
        });

        float oa = anim(new K(m, "o"), OPEN.contains(m) ? 1f : 0f, 12f);
        int ah = Math.round(settingsHeight(m) * oa);
        int ny = y + ROW;
        if (ah > 0) {
            int sTop = Math.max(ny, pTop), sBot = Math.min(ny + ah, pBottom);
            g.fill(x, ny, x + PW, ny + ah, 0x40000000);
            if (sBot > sTop) {
                g.enableScissor(x, sTop, x + PW, sBot);
                int oldTop = clipTop, oldBot = clipBottom;
                clipTop = Math.max(clipTop, sTop); clipBottom = Math.min(clipBottom, sBot);
                int sy = ny;
                for (Setting s : m.settings()) {
                    if (!s.isVisible()) continue;
                    sy += renderSetting(g, s, x, sy, mx, my);
                }
                g.disableScissor();
                clipTop = oldTop; clipBottom = oldBot;
            }
        }
        return y + ROW + ah;
    }

    private int renderSetting(DrawContext g, Setting s, int x, int y, int mx, int my) {
        TextRenderer tr = textRenderer;
        final int LABEL = 0xFFC4CAD6, MUTED = 0xFF8F97A8;

        if (s instanceof BoolSetting b) {
            g.drawText(tr, b.name, x + 11, y + 3, LABEL, false);
            float t = anim(new K(s, "b"), b.get() ? 1f : 0f, 16f);
            pill(g, x + PW - 26, y + 3, 18, 8, t);
            addHit(x, y, x + PW, y + 14, (bt, ax, ay) -> { if (bt == 0) b.toggle(); });
            return 14;
        }

        if (s instanceof NumberSetting n) {
            g.drawText(tr, n.name, x + 11, y + 3, LABEL, false);
            String v = n.display();
            g.drawText(tr, v, x + PW - 9 - tr.getWidth(v), y + 3, MUTED, false);
            int bx = x + 11, bw = PW - 22, by = y + 15;
            g.fill(bx, by, bx + bw, by + 3, 0xFF232834);
            float af = anim(new K(s, "n"), (float) n.fraction(), 22f);
            int fw = Math.round(bw * af);
            if (fw > 0) gradient(g, bx, by, fw, 3, t -> ColorUtil.lerp(accent, accent2, (float) t) | 0xFF000000);
            g.fill(bx + fw - 1, by - 2, bx + fw + 1, by + 5, 0xFFFFFFFF);
            addHit(bx - 4, y + 9, bx + bw + 4, y + 22, (bt, ax, ay) -> {
                if (bt != 0) return;
                Drag d = (nx, ny) -> n.setFraction((nx - bx) / bw);
                drag = d;
                d.to(ax, ay);
            });
            return 22;
        }

        if (s instanceof ModeSetting md) {
            g.drawText(tr, md.name, x + 11, y + 3, LABEL, false);
            String v = md.get();
            g.drawText(tr, v, x + PW - 9 - tr.getWidth(v), y + 3, 0xFF000000 | accent, false);
            addHit(x, y, x + PW, y + 14, (bt, ax, ay) -> { if (bt == 0) md.next(); else if (bt == 1) md.prev(); });
            return 14;
        }

        if (s instanceof ColorSetting c) {
            g.drawText(tr, c.name, x + 11, y + 3, LABEL, false);
            rrect(g, x + PW - 32, y + 2, 24, 10, 0xFF3A4152, true, true);
            rrect(g, x + PW - 31, y + 3, 22, 8, 0xFF000000 | c.rgb(), true, true);
            addHit(x, y, x + PW, y + 14, (bt, ax, ay) -> { if (!COLOR_OPEN.remove(c)) COLOR_OPEN.add(c); });

            float oa = anim(new K(s, "c"), COLOR_OPEN.contains(c) ? 1f : 0f, 12f);
            int ph = Math.round(COLOR_PICKER_H * oa);
            if (ph > 0) {
                int top = y + 14, bot = top + ph;
                g.enableScissor(x, top, x + PW, bot);
                int oldTop = clipTop, oldBot = clipBottom;
                clipTop = Math.max(clipTop, top); clipBottom = Math.min(clipBottom, bot);

                int bx = x + 11, bw = PW - 22;
                float hh = c.hue(), ss = c.sat(), bb = c.bri();
                slider(g, bx, top + 2, bw, t -> 0xFF000000 | ColorUtil.hsb((float) t, 0.85f, 1f), hh,
                        f -> c.setHue(f));
                slider(g, bx, top + 15, bw, t -> 0xFF000000 | ColorUtil.hsb(hh, (float) t, Math.max(0.35f, bb)), ss,
                        f -> c.setSat(f));
                slider(g, bx, top + 28, bw, t -> 0xFF000000 | ColorUtil.hsb(hh, ss, (float) t), bb,
                        f -> c.setBri(f));

                g.disableScissor();
                clipTop = oldTop; clipBottom = oldBot;
            }
            return 14 + ph;
        }
        return 0;
    }

    /** A 8px-high gradient slider with a marker; registers a drag hit. */
    private void slider(DrawContext g, int x, int y, int w, DoubleToIntFunction grad, float value,
                        java.util.function.DoubleConsumer setter) {
        gradient(g, x, y, w, 8, grad);
        int mxp = x + Math.round(w * value);
        g.fill(mxp - 1, y - 1, mxp + 1, y + 9, 0xFFFFFFFF);
        addHit(x - 3, y - 1, x + w + 3, y + 10, (bt, ax, ay) -> {
            if (bt != 0) return;
            Drag d = (nx, ny) -> setter.accept((nx - x) / w);
            drag = d;
            d.to(ax, ay);
        });
    }

    private int settingsHeight(Module m) {
        int h = 0;
        for (Setting s : m.settings()) {
            if (!s.isVisible()) continue;
            if (s instanceof NumberSetting) h += 22;
            else if (s instanceof ColorSetting) h += 14 + Math.round(COLOR_PICKER_H * ANIMS.getOrDefault(new K(s, "c"), 0f));
            else h += 14;
        }
        return h;
    }

    private float openAmount(Module m) { return ANIMS.getOrDefault(new K(m, "o"), OPEN.contains(m) ? 1f : 0f); }

    // ============================================================ drawing helpers

    private float anim(Object key, float target, float speed) {
        float v = ANIMS.getOrDefault(key, target);
        v += (target - v) * Math.min(1f, dt * speed);
        if (Math.abs(target - v) < 0.002f) v = target;
        ANIMS.put(key, v);
        return v;
    }

    private void addHit(int x1, int y1, int x2, int y2, Act act) {
        hits.add(new Hit(x1, y1, x2, y2, clipTop, clipBottom, act));
    }

    private void pill(DrawContext g, int x, int y, int w, int h, float t) {
        rrect(g, x, y, w, h, 0xFF000000 | ColorUtil.lerp(0x2A303D, accent, t), true, true);
        int kx = x + 1 + Math.round((w - h) * t);
        rrect(g, kx, y + 1, h - 2, h - 2, 0xFFFFFFFF, true, true);
    }

    /** Horizontal gradient from a function of t in [0,1]. */
    private static void gradient(DrawContext g, int x, int y, int w, int h, DoubleToIntFunction f) {
        for (int i = 0; i < w; i += 3) {
            int seg = Math.min(3, w - i);
            g.fill(x + i, y, x + i + seg, y + h, f.applyAsInt((i + seg * 0.5) / Math.max(1, w)));
        }
    }

    /** Rectangle with 2px rounded corners (top and/or bottom pair). */
    private static void rrect(DrawContext g, int x, int y, int w, int h, int c, boolean top, boolean bot) {
        if (w <= 4 || h <= 4) { g.fill(x, y, x + w, y + h, c); return; }
        int i0 = top ? 2 : 0, i1 = top ? 1 : 0, j1 = bot ? 1 : 0, j0 = bot ? 2 : 0;
        g.fill(x + i0, y, x + w - i0, y + 1, c);
        g.fill(x + i1, y + 1, x + w - i1, y + 2, c);
        g.fill(x, y + 2, x + w, y + h - 2, c);
        g.fill(x + j1, y + h - 2, x + w - j1, y + h - 1, c);
        g.fill(x + j0, y + h - 1, x + w - j0, y + h, c);
    }

    // ============================================================ input

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int b = click.button();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mx >= h.x1() && mx < h.x2() && my >= h.y1() && my < h.y2() && my >= h.clipTop() && my < h.clipBottom()) {
                h.act().run(b, mx, my);
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (drag != null) { drag.to(click.x(), click.y()); return true; }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        drag = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (int i = PANELS.size() - 1; i >= 0; i--) {
            PanelState p = PANELS.get(i);
            if (p.collapsed) continue;
            if (mouseX >= p.x && mouseX < p.x + PW && mouseY >= p.y + HEAD && mouseY < p.y + HEAD + p.visibleH) {
                p.scroll = Math.max(0, Math.min(p.scroll - verticalAmount * 14, Math.max(0, p.contentH - p.visibleH)));
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(input);
    }
}
