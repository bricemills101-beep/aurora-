package dev.aurora;

import dev.aurora.module.Freecam;
import dev.aurora.module.ModuleManager;
import dev.aurora.render.Overlay;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.util.Identifier;

public class AuroraClient implements ClientModInitializer {
    public static final String ID = "aurora";

    @Override
    public void onInitializeClient() {
        ModuleManager.init();

        HudElementRegistry.attachElementAfter(VanillaHudElements.MISC_OVERLAYS,
                Identifier.of(ID, "esp"), Overlay::render);

        ClientTickEvents.START_CLIENT_TICK.register(Freecam::preTick);
        ClientTickEvents.END_CLIENT_TICK.register(ModuleManager::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ModuleManager.onDisconnect());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> ModuleManager.save());
    }
}
