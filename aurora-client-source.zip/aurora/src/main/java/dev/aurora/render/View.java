package dev.aurora.render;

import dev.aurora.module.Freecam;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** A manual camera -> screen projection used by the 2D overlay ESP. */
public final class View {
    public final double px, py, pz;
    private final double fx, fy, fz, rx, rz, ux, uy, uz;
    private final double tanHalf, aspect;
    public final int w, h;

    private View(double px, double py, double pz, float yaw, float pitch, double fovDeg, int w, int h) {
        this.px = px; this.py = py; this.pz = pz; this.w = w; this.h = h;
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        double sy = Math.sin(yr), cy = Math.cos(yr), sp = Math.sin(pr), cp = Math.cos(pr);
        fx = -sy * cp; fy = -sp; fz = cy * cp;      // forward
        rx = -cy;      /* ry = 0 */ rz = -sy;       // right
        ux = -sy * sp; uy = cp;      uz = cy * sp;  // up
        tanHalf = Math.tan(Math.toRadians(fovDeg) / 2.0);
        aspect = (double) w / (double) h;
    }

    /** Camera position independent of perspective (used for scanning). */
    public static Vec3d cameraPos(MinecraftClient mc, float delta) {
        if (Freecam.active()) return new Vec3d(Freecam.x, Freecam.y, Freecam.z);
        return mc.player.getCameraPosVec(delta);
    }

    /** Returns null when the overlay cannot be aligned (third person without freecam). */
    public static View build(MinecraftClient mc, float delta, int w, int h) {
        ClientPlayerEntity p = mc.player;
        if (p == null || w <= 0 || h <= 0) return null;
        double fov = mc.options.getFov().getValue();
        if (Freecam.active()) {
            return new View(Freecam.x, Freecam.y, Freecam.z, Freecam.yaw, Freecam.pitch, fov, w, h);
        }
        if (!mc.options.getPerspective().isFirstPerson()) return null;
        Vec3d c = p.getCameraPosVec(delta);
        return new View(c.x, c.y, c.z, p.getYaw(delta), p.getPitch(delta), fov, w, h);
    }

    public double distanceTo(double x, double y, double z) {
        double dx = x - px, dy = y - py, dz = z - pz;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** world -> camera space: out = (right, up, forward). */
    public void toCam(double x, double y, double z, double[] out) {
        double dx = x - px, dy = y - py, dz = z - pz;
        out[0] = dx * rx + dz * rz;
        out[1] = dx * ux + dy * uy + dz * uz;
        out[2] = dx * fx + dy * fy + dz * fz;
    }

    /** camera space (forward > 0) -> GUI-scaled screen coordinates. */
    public void project(double[] cam, double[] out) {
        out[0] = (0.5 + 0.5 * cam[0] / (cam[2] * tanHalf * aspect)) * w;
        out[1] = (0.5 - 0.5 * cam[1] / (cam[2] * tanHalf)) * h;
    }
}
