package dev.aurora.render;

import dev.aurora.module.EspModule;
import dev.aurora.util.ColorUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Box;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Draws wireframes / fills by projecting box corners to the screen and drawing with DrawContext.
 * Corner i: x = bit0, y = bit1, z = bit2 (0 = min, 1 = max).
 */
public final class EspRenderer {
    private static final double NEAR = 0.05;
    private static final int[][] EDGES = {
            {0, 1}, {2, 3}, {4, 5}, {6, 7},   // along x
            {0, 2}, {1, 3}, {4, 6}, {5, 7},   // along y
            {0, 4}, {1, 5}, {2, 6}, {3, 7}    // along z
    };

    private EspRenderer() {}

    public static void render(DrawContext g, EspModule m, View v, long now) {
        List<EspModule.Entry> list = m.entries();
        if (list.isEmpty()) return;

        String mode = m.mode.get();
        boolean fill = mode.equals("Filled") || mode.equals("Outline + Fill");
        float outlineA = m.outlineOpacity.floatValue() / 100f;
        float fillA = m.fillOpacity.floatValue() / 100f;
        float tracerA = m.tracerOpacity.floatValue() / 100f;
        int lw = m.lineWidth.intValue();
        double range = m.range.get();
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int W = v.w, H = v.h;

        double[][] cam = new double[8][3];
        double[][] seg = new double[12][4];
        boolean[] ok = new boolean[12];
        double[] ca = new double[3], cb = new double[3], s0 = new double[2], s1 = new double[2];
        double[] cc = new double[3], sc = new double[2];

        for (EspModule.Entry e : list) {
            Box b = e.box();
            double cx = (b.minX + b.maxX) * 0.5, cy = (b.minY + b.maxY) * 0.5, cz = (b.minZ + b.maxZ) * 0.5;
            double dist = v.distanceTo(cx, cy, cz);
            if (dist > range) continue;

            float fade = m.distanceFade.get() ? 1f - 0.65f * (float) Math.min(1.0, dist / range) : 1f;
            int rgb = switch (m.colorMode.get()) {
                case "Rainbow" -> ColorUtil.hsb(((now % 1_000_000L) * m.rainbowSpeed.floatValue() / 10000f)
                        + (float) (dist * 0.01), 0.75f, 1f);
                case "Distance" -> ColorUtil.hsb((float) Math.max(0, 1.0 - dist / range) * 0.33f, 0.85f, 1f);
                default -> e.color().rgb();
            };

            for (int i = 0; i < 8; i++) {
                v.toCam((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY,
                        (i & 4) == 0 ? b.minZ : b.maxZ, cam[i]);
            }

            // project every edge (clipped against the near plane)
            double minX = 1e18, minY = 1e18, maxX = -1e18, maxY = -1e18;
            List<double[]> pts = new ArrayList<>(24);
            boolean any = false;
            for (int k = 0; k < 12; k++) {
                ok[k] = clipNear(cam[EDGES[k][0]], cam[EDGES[k][1]], ca, cb);
                if (!ok[k]) continue;
                v.project(ca, s0);
                v.project(cb, s1);
                seg[k][0] = s0[0]; seg[k][1] = s0[1]; seg[k][2] = s1[0]; seg[k][3] = s1[1];
                pts.add(new double[]{s0[0], s0[1]});
                pts.add(new double[]{s1[0], s1[1]});
                minX = Math.min(minX, Math.min(s0[0], s1[0])); maxX = Math.max(maxX, Math.max(s0[0], s1[0]));
                minY = Math.min(minY, Math.min(s0[1], s1[1])); maxY = Math.max(maxY, Math.max(s0[1], s1[1]));
                any = true;
            }

            // tracer (independent of whether the box itself is on screen)
            if (m.tracers.get()) {
                v.toCam(cx, cy, cz, cc);
                if (cc[2] > NEAR) {
                    v.project(cc, sc);
                    double ox = W / 2.0, oy = m.tracerOrigin.is("Bottom") ? H : H / 2.0;
                    line(g, ox, oy, sc[0], sc[1], W, H, Math.max(1, lw - 1 + 1),
                            ColorUtil.argb(rgb, tracerA * fade));
                }
            }

            if (!any) continue;
            if (maxX < 0 || minX > W || maxY < 0 || minY > H) continue;

            if (fill) fillHull(g, pts, minY, maxY, W, H, ColorUtil.argb(rgb, fillA * fade));

            int lineColor = ColorUtil.argb(rgb, outlineA * fade);
            switch (mode) {
                case "Outline", "Outline + Fill" -> {
                    for (int k = 0; k < 12; k++) {
                        if (ok[k]) line(g, seg[k][0], seg[k][1], seg[k][2], seg[k][3], W, H, lw, lineColor);
                    }
                }
                case "Corners" -> {
                    for (int k = 0; k < 12; k++) {
                        if (!ok[k]) continue;
                        double x0 = seg[k][0], y0 = seg[k][1], x1 = seg[k][2], y1 = seg[k][3];
                        double t = 0.3;
                        line(g, x0, y0, x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, W, H, lw, lineColor);
                        line(g, x1, y1, x1 - (x1 - x0) * t, y1 - (y1 - y0) * t, W, H, lw, lineColor);
                    }
                }
                case "Flat Box" -> {
                    line(g, minX, minY, maxX, minY, W, H, lw, lineColor);
                    line(g, minX, maxY, maxX, maxY, W, H, lw, lineColor);
                    line(g, minX, minY, minX, maxY, W, H, lw, lineColor);
                    line(g, maxX, minY, maxX, maxY, W, H, lw, lineColor);
                }
                default -> { }
            }

            if (m.labels.get()) {
                String text = e.label() + (m.showDistance.get() ? "  " + Math.round(dist) + "m" : "");
                int tx = (int) ((minX + maxX) / 2) - tr.getWidth(text) / 2;
                int ty = (int) minY - 11;
                if (ty > -10 && ty < H && tx > -200 && tx < W) {
                    g.drawText(tr, text, tx, ty, ColorUtil.argb(rgb, Math.max(0.35f, fade)), true);
                }
            }
        }
    }

    // ---------------------------------------------------------------- geometry

    /** Clips the camera-space segment a-b to forward > NEAR. Writes into oa/ob. Returns false if fully behind. */
    private static boolean clipNear(double[] a, double[] b, double[] oa, double[] ob) {
        boolean aIn = a[2] > NEAR, bIn = b[2] > NEAR;
        if (!aIn && !bIn) return false;
        System.arraycopy(a, 0, oa, 0, 3);
        System.arraycopy(b, 0, ob, 0, 3);
        if (!aIn) {
            double t = (NEAR - a[2]) / (b[2] - a[2]);
            for (int i = 0; i < 3; i++) oa[i] = a[i] + (b[i] - a[i]) * t;
            oa[2] = NEAR;
        } else if (!bIn) {
            double t = (NEAR - b[2]) / (a[2] - b[2]);
            for (int i = 0; i < 3; i++) ob[i] = b[i] + (a[i] - b[i]) * t;
            ob[2] = NEAR;
        }
        return true;
    }

    /** Line with Liang-Barsky clipping to the screen, drawn as merged runs of rectangles. */
    private static void line(DrawContext g, double x0, double y0, double x1, double y1, int W, int H, int thick, int color) {
        double dx = x1 - x0, dy = y1 - y0, t0 = 0, t1 = 1;
        double[] p = {-dx, dx, -dy, dy};
        double[] q = {x0, W - x0, y0, H - y0};
        for (int i = 0; i < 4; i++) {
            if (p[i] == 0) {
                if (q[i] < 0) return;
            } else {
                double r = q[i] / p[i];
                if (p[i] < 0) { if (r > t1) return; if (r > t0) t0 = r; }
                else { if (r < t0) return; if (r < t1) t1 = r; }
            }
        }
        int ax = (int) Math.round(x0 + dx * t0), ay = (int) Math.round(y0 + dy * t0);
        int bx = (int) Math.round(x0 + dx * t1), by = (int) Math.round(y0 + dy * t1);
        int adx = Math.abs(bx - ax), ady = Math.abs(by - ay);

        if (adx == 0 && ady == 0) { g.fill(ax, ay, ax + thick, ay + thick, color); return; }

        if (adx >= ady) {
            int sx = bx > ax ? 1 : -1;
            double slope = (double) (by - ay) / (bx - ax);
            int runStart = ax, curY = ay;
            for (int i = 0; i <= adx; i++) {
                int x = ax + i * sx;
                int y = (int) Math.round(ay + slope * (x - ax));
                if (y != curY) {
                    int xe = x - sx;
                    g.fill(Math.min(runStart, xe), curY, Math.max(runStart, xe) + 1, curY + thick, color);
                    runStart = x; curY = y;
                }
            }
            g.fill(Math.min(runStart, bx), curY, Math.max(runStart, bx) + 1, curY + thick, color);
        } else {
            int sy = by > ay ? 1 : -1;
            double slope = (double) (bx - ax) / (by - ay);
            int runStart = ay, curX = ax;
            for (int i = 0; i <= ady; i++) {
                int y = ay + i * sy;
                int x = (int) Math.round(ax + slope * (y - ay));
                if (x != curX) {
                    int ye = y - sy;
                    g.fill(curX, Math.min(runStart, ye), curX + thick, Math.max(runStart, ye) + 1, color);
                    runStart = y; curX = x;
                }
            }
            g.fill(curX, Math.min(runStart, by), curX + thick, Math.max(runStart, by) + 1, color);
        }
    }

    /** Fills the convex hull of the projected points (= the silhouette of the box) with horizontal scanlines. */
    private static void fillHull(DrawContext g, List<double[]> pts, double minY, double maxY, int W, int H, int color) {
        if (pts.size() < 3) return;
        List<double[]> sorted = new ArrayList<>(pts);
        sorted.sort(Comparator.<double[]>comparingDouble(a -> a[0]).thenComparingDouble(a -> a[1]));
        int n = sorted.size();
        double[][] hull = new double[2 * n][];
        int k = 0;
        for (int i = 0; i < n; i++) {
            while (k >= 2 && cross(hull[k - 2], hull[k - 1], sorted.get(i)) <= 0) k--;
            hull[k++] = sorted.get(i);
        }
        for (int i = n - 2, t = k + 1; i >= 0; i--) {
            while (k >= t && cross(hull[k - 2], hull[k - 1], sorted.get(i)) <= 0) k--;
            hull[k++] = sorted.get(i);
        }
        int hn = k - 1;
        if (hn < 3) return;

        int y0 = (int) Math.max(0, Math.floor(minY)), y1 = (int) Math.min(H, Math.ceil(maxY));
        int step = (y1 - y0) > 160 ? 2 : 1;
        for (int y = y0; y < y1; y += step) {
            double yc = y + step * 0.5, lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
            for (int i = 0; i < hn; i++) {
                double[] a = hull[i], b = hull[(i + 1) % hn];
                if ((a[1] <= yc && b[1] > yc) || (b[1] <= yc && a[1] > yc)) {
                    double x = a[0] + (yc - a[1]) / (b[1] - a[1]) * (b[0] - a[0]);
                    lo = Math.min(lo, x); hi = Math.max(hi, x);
                }
            }
            if (hi > lo) {
                int xl = (int) Math.max(0, Math.min(W, lo)), xr = (int) Math.max(0, Math.min(W, hi));
                if (xr > xl) g.fill(xl, y, xr, y + step, color);
            }
        }
    }

    private static double cross(double[] o, double[] a, double[] b) {
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
    }
}
