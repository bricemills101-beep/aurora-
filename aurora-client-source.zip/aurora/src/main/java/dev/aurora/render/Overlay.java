package dev.aurora.render;

import dev.aurora.module.EspModule;
import dev.aurora.module.Module;
import dev.aurora.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public final class Overlay {
    private Overlay() {}

    public static void render(DrawContext g, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;

        View view = null;
        long now = System.currentTimeMillis();
        for (Module m : ModuleManager.MODULES) {
            if (m instanceof EspModule esp && esp.isEnabled()) {
                if (view == null) {
                    view = View.build(mc, tickCounter.getTickProgress(false),
                            g.getScaledWindowWidth(), g.getScaledWindowHeight());
                    if (view == null) return;
                }
                EspRenderer.render(g, esp, view, now);
            }
        }
    }
}
