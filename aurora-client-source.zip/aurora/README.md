# Aurora Client (Fabric, Minecraft 1.21.11)

Client-only mod: ClickGUI, StorageFinder, SpawnerFinder, Freecam.

## Build
1. Install JDK 21.
2. Get a Gradle wrapper: easiest is to generate a blank project at https://fabricmc.net/develop/template/ (1.21.11, Yarn, Java 21),
   then copy this project's `src/`, `build.gradle`, `gradle.properties`, `settings.gradle` over it.
   (Or, with Gradle 9.x installed: run `gradle wrapper` in this folder.)
3. `./gradlew build`  (Windows: `gradlew.bat build`)
4. Jar: `build/libs/aurora-client-1.0.0.jar` (not the `-sources` one)

## Install
Put the jar in `.minecraft/mods` together with Fabric API (0.141.1+1.21.11 or newer for 1.21.11) and Fabric Loader >= 0.18.

## Use
- Right Shift: open ClickGUI (rebindable under Controls > Aurora Client)
- Each module has an unbound toggle key in Controls > Aurora Client (bind Freecam there)
- GUI: left click = toggle, right click = expand settings, drag headers, scroll long panels
- Config is saved to `config/aurora.json`

## No local setup: build the jar on GitHub
1. Create a new GitHub repo and upload this whole folder (including the hidden `.github` folder).
2. Open the repo's Actions tab; the "build" workflow runs automatically (or click Run workflow).
3. When it finishes, open the run and download the `aurora-client-jar` artifact. The jar is inside.
